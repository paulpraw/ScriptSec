echo "hi " 
sleep 2
echo "bye hoe"

