echo "hello"
sleep 3
echo "goodbye"

