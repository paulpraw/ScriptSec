echo "and another test script"
