echo "this is test script #2"

