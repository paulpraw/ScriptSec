#!/bin/bash
# modifying a set trap
#
trap "echo ' Sorry... Ctrl-C is trapped.'" SIGINT

count=1
while [ $count -le 5 ]
do
	   echo "Loop #$count"
