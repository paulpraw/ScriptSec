#piping a loop to another command

for state in "North Dakota" Connecticut Illinois Alabama Tennesee
do
	echo "$state is the next place to go"
done | sort
echo "THis completes our travels"

