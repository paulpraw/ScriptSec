#testing c style for loop

for (( i=1; i <= 10; i++ ))
do
	echo "the next number is $i"
done

