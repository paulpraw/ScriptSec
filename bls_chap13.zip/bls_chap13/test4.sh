#using a variable to hold the list

list="Alabama Alaska Arizon Arkansas Colorado"
list=$list" Connecticut"

for state in $list
do
	echo "Have you ever visted $state?"
done
