#an example of how to properly define values

for test in Nevada "New Hampshire" "New Mexico" "New York"
do
	echo "Now going to $test"
done
