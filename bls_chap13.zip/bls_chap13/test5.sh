#reading from a file

file="states"

for state in $(cat $file)
do
	echo "Visit beautiful $state"
done
