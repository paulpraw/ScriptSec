# basic for command

for test in Alabama Alaska Arizona Arkansas California Colorado
do
	echo The next state is $test
done
