#!/bin/bash

shtool platform
