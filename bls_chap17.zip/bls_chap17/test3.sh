#!/bin/bash
# testing using a duplicate function name

function func1 {
echo "this is the first definition of the function name"
}

func1

function func1 {
	echo "this is a repeat of the same function name"
}

func1
echo "this is the end of the script"


