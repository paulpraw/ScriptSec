testuser=NoSuchUser
#testing the else section
if grep $testuser /etc/passwd
then

	echo "The bash files for the $testuser are:"
	ls -a /home/$testuser/.b*
	echo
else
	echo "The user $testuser does not exist on this system."
	echo
fi

