pwfile=/etc/shadow
#test if file exists, and is a file
if [ -f $pwfile ]
then
	#now test if you can read it
if [ -r $pwfile ]
	then
		tail $pwfile
	else
		echo "Sorry, I am unable to read the $pwfile file"
	fi
else
	echo "Sorrry, the file $file does not exist."
fi

