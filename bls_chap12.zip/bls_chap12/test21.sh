#!/bin/bash
#testing file dates

if [ badfile1 -nt badfile2 ]
then
	echo "the badfile1 is newer than badfile2"
else
	echo "the badfile2 is newer than badfile1"
fi

