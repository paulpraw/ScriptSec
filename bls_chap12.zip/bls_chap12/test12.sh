location=$HOME
file_name="sentinel"

if [ -e $location ]
then #Directory does not exist
	echo "OK on the $location directory"
	echo "Now checking on the file, $file_name."

	if [ -e $location/$file_name ]
	then #file does exist
		echo "OK on the filename"
		echo "Updating current date..."
		date >> $location/$file_name

	else #file does not exist
		echo "File does not exist"
		echo "nothing to update"
	fi
#
else #directory does not exist
	echo "The $location directory does not exist."
	echo "Nothing to update"
fi

