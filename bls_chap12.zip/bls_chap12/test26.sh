#using the case command

case $USER in
paul | barbara)
	echo "Welcome, $USER"
	echo "Please enjoy your visit";;
testing)
	echo "special testing account";;
jessica)
	echo "Do not forget to log off when youre done";;
*)
	echo "sorry, you are not allowed here";;
esac
