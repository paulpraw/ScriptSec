# looking for a possible value

if [ $USER = "paul" ]
then
	echo "welcome $USER"
	echo "please enjoy your visit"
elif [ $USER = "barbara" ]
then
	echo "welcome $USER"
	echo "please enjoy your visit"
elif [ $USER = "testing" ]
then
	echo "Special testing account"
elif [ $USER = "jessica"
then
	echo "Do not forget to log out when yoiure done"
else
	echo "Sorry, you are not allowed here"
fi
