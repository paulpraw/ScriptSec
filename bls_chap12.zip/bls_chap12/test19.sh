#check file group test

if [ -G $HOME/testing ]
then
	echo "you are in the same group s the file"
else
	echo "The file is not owned by your group"
fi
