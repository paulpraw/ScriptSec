#!/bin/bash
#entering multiple variables
#
read -p "Enter your name: " first last
echo "Checking data for $last, $first..."

