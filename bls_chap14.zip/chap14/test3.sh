#!/bin/bash
#testing string pararmeters
#
echo Hello $1, glad to meet you.

