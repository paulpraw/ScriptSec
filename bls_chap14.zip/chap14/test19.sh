#!/bin/bash
#simple demonstration of the getopt command
#
echo
while getopts :ab:c opt
do
	case "$opt" in
		a) echo "found the -a option" ;;
		b) echo "found the -b option, with value $OPTARG";;
		c) echo "found the -c option" ;;
		*) echo "Unknown option: $opt";;
	esac
done
