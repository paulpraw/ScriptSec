#!/bin/bash
#getting the number of parameters
#
echo There were $# parameters supplied.

