#!/bin/bash
#handling lots of parameters
#
total=$[ ${10} * ${11} ]
echo the tenth parameter is ${10}
echo the eleventh parameter is ${11}
echo the total is $total
