#!/bin/bash
#testing the read command
#
echo -n "enter your name: "
read name
echo "Hello $name, welcome to my program. "
#
