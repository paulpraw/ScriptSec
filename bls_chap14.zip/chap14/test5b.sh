#!/bin/bash
#using the basename with the $0 parameter

name=$(basename $0)
echo
echo the script name is $name
