#!/bin/bash
#testing two command line parameters
#
total=$[ $1 * $2 ]
echo the first parameter is $1
echo the second paramenter is $2
echo the total value is $total
