#!/bin/bash
#testing the $0 parameter

echo the zero parameter is set to: $0
