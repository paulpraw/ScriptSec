#!/bin/bash
#redirecting all output to different locations

exec 2>testerro

echo "This is the start of the script"
echo "now redirecting all output to another location"

exec 1>testout

echo "this output shoudl go in the testout file"
echo "but this should go to the testerror file" >&2

