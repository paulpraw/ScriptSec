#!/bin/bash
#testing STDERR messages

echo "this is an error" >&2
echo "this is normal output"
