 #!/bin/bash
# testing closing file descriptors

exec 3> test17file
echo "this is a test line of data" >&3

exec 3>&-

echo "this wont work" >&3

