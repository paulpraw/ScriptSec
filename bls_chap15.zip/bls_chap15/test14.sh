#!/bin/bash
# storing STDOUT, then coming back to it

exec 3>&1
exec 1>test14out

echo "This should store output in the file"
echo "along with this line"

exec 1>&3

echo "Now things should go back to normal"
